# Capacity model: exported tables

These tables describe the **production model as it stands**: the v2 convergence model with the transmission term and the Viksit Bharat ($30 trillion) GDP outlook.

The frozen-data fixes (float copies, solar-only nowcast) are **not** applied. They appear only as tested alternatives.

To regenerate: `.venv/bin/python model/export_tables.py`.

Sources are solar, wind, bio-mass, small hydro and waste-to-energy. MW = installed capacity.

| # | File | Contents |
|---|---|---|
| 1 | `backtest_predictions.csv` | Every backtest test row (3,910): cutoff, state, zone, source, year, horizon, actual, predicted, error, and whether it was scored (fresh report) |
| 2 | `error_summary.csv` | WAPE and signed error by source, state, zone and horizon, for each cutoff set |
| 3 | `dataset_schema.csv`, `year_coverage.csv`, `fresh_flags.csv`, `fresh_summary.csv` | Columns and units; years covered per state; fresh/stale flag for every state, year and source; share fresh and last fresh year |
| 4 | `growth_coefficients.csv`, `year_effects.csv`, `constants.csv` | Growth equation with fitted coefficients; national year effects; all 48 hand-set constants and where they live |
| 5 | `nowcast_stale_states.csv` | 2022–2024 nowcast next to the last reported value, per stale state and source (46 rows) |
| 6 | `gsdp_population_projection.csv` | Per-state GSDP (real and current prices) and population for 2024, 2030 and 2047, for every GDP outlook |
| 7 | `ablations.csv` | Backtest error with each model term removed or changed, per cutoff |
| 8 | `national_capacity.csv`, `capacity_factors.csv` | India capacity and generation by source, 2024–2047, every outlook; utilisation factors and cost benchmarks |
| 9 | `data_fixes.csv` | Every data fix: evidence, what was done, status |

## Key numbers

**Error**, scored on fresh reports only:

| | Standard cutoffs (2016, 2018, 2020) | Recent cutoffs (2020, 2021, 2022) |
|---|---|---|
| Headline: mean of each cutoff's WAPE | 29.2% | 29.7% |
| All cutoffs pooled into one WAPE | 29.9% | 28.7% |
| Signed error, pooled | −8.8% (under-forecast) | −21.3% |

The headline and pooled figures differ because pooling gives larger test sets more weight.

**Error by source** (standard cutoffs): solar 41.7%, wind 10.6%, bio-mass 17.0%, small hydro 9.2%, waste-to-energy 69.1%.
- Solar is under-forecast by 12.7%.

**Error by horizon** (standard cutoffs): 15% one year ahead, rising to 45% eight years ahead.
- Signed error goes from +1% to −32%: the model under-forecasts more the further ahead it looks.

**Largest absolute misses** (standard cutoffs): Gujarat (−38%), Rajasthan (−37%), Maharashtra (−14%).
- Tamil Nadu is the one big state that is over-forecast (+21%).

**Ablations** (average of both cutoff sets; production is 29.5%):

| Change | Average error | vs production |
|---|---|---|
| Remove the transmission term | 34.3% | +4.8 |
| Remove the GSDP term | 31.8% | +2.3 |
| Trend half-life 2 years | 31.0% | +1.5 |
| Trend half-life 5 years | 30.5% | +1.0 |
| Remove catch-up | 29.7% | +0.2 (worse on standard cutoffs, better on recent ones) |
| No nowcast | 29.6% | +0.1 |
| Fill stale years for solar only (tested alternative) | 29.3% | −0.2 |
| v1 GDP model alone | 36.3% | +6.8 |
| Naive: no new capacity | 44.1% | +14.6 |

**National forecast** (Viksit Bharat outlook):

| | 2024 | 2030 | 2035 | 2040 | 2047 |
|---|---|---|---|---|---|
| Capacity | 196 GW | 413 GW | 546 GW | 680 GW | 900 GW |
| Generation | 464 TWh | 882 TWh | 1,146 TWh | 1,419 TWh | 1,878 TWh |

In 2047, India's GSDP is ₹824 lakh crore at 2011-12 prices, or ₹7,365 lakh crore at current prices ($30 trillion). Population is 168 crore.

**Capacity factors:** solar 21%, wind 30%, bio-mass 75%, small hydro 45%, waste-to-energy 70%. These are CERC/MNRE benchmarks, not learned from the data.

## Caveats
- **Some last-report years are wrong.** The nowcast table lists 2022 as the last fresh year for Rajasthan, Tamil Nadu and others, but their 2022 values are float32 copies of 2021. That is the known, unapplied issue in `data_fixes.csv`.
- **Bio-mass and small hydro** use the v1 GDP-elasticity rule, so their v2 coefficient cells are blank.
- **Population is not a model input.** It is projected at 0.8% a year only for per-person figures.
